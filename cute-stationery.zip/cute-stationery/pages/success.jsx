export default function Success() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-cream font-cute text-pink-dark text-2xl">
      💖 پرداخت موفق بود! مرسی از خریدت 🎀
    </div>
  );
}

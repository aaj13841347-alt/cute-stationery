import React from 'react';
import CuteShop from '../components/CuteShop';

export default function Home(){
  return <CuteShop />;
}
